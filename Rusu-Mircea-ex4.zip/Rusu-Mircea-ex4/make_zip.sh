zip -r Rusu-Mircea-in.zip Rusu-Mircea-in -x Rusu-Mircea-in/lib/* Rusu-Mircea-in/.idea/* Rusu-Mircea-in/.settings/*
